import mysql.connector as m

def connect():
    con = m.connect(host="localhost", user="root", password="SYSTEM")
    return con

db_name = "sabarmati_hospital"
