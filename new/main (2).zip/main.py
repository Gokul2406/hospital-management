from cryptography.fernet import Fernet
from auth import signup, login
from util import connect
from admin import add_doctors, remove_doctors, add_patients, remove_patients, update_doctors
import sys


def setup():
    con = connect()
    cur = con.cursor()
    db_name = "sabarmathi_hospital"
    cur.execute(f"create database if not exists {db_name}")
    cur.execute(f"use {db_name}")
    cur.execute("create table if not exists doctors(doc_id int primary key, name varchar(25), dept varchar(25), salary int, working_hrs int, fees int)")
    cur.execute("create table if not exists patients(id int primary key, name varchar(25), age int, doc_id int, reason varchar(50))")
    cur.execute("create table if not exists pharmacy(id int primary key, med_name varchar(25), stock int, price int)")
    cur.execute("create table if not exists users(id int primary key, username varchar(25), password varchar(500))")
    cur.execute("create table if not exists misc(encrypt_key varchar(500))")
    key_fetch = "select * from misc"
    cur.execute(key_fetch)
    res = cur.fetchall()
    if len(res) == 0:
        key = Fernet.generate_key()
        cur.execute("insert into misc values('{}')".format(key.decode("utf-8")))
    cur.close()
    con.commit()
    con.close()


if __name__ == "__main__":
    setup()
    print("""
                ==============================================
                
                            ----------SABARMATI  HOSPITAL---------------
                 ===============================================


                 1) Sign up
                 2) Login
                 
                 """)
   
    while True:
        ch= int(input("Enter choice: "))
        if ch==1:
            username=input("ENTER USERNAmE :")
            passwrd=input("ENTER PASSWRD :")
            signup(username,passwrd, False)
        elif ch==2:
            username=input("ENTER USERNAME :")
            passwrd=input("ENTER PASSWRD :")
            res = login(username,passwrd)

            if res == True:
                print("""Admin Menu"

                            1) Add doctors
                            2) Remove doctors
                            3) Add patient
                            4) Remove patients
""")
                ch = int(input("Enter choice: "))
                if ch == 1:
                    add_doctors()
                elif ch == 2:
                    remove_doctors()
                elif ch == 3:
                    add_patients()
                elif ch == 4:
                    remove_patients()
                elif ch == 5:
                    update_doctors()
            else:
                sys.exit(0)
                
        else:
            break
    

    #signup("hi", "hil", False)
#    login("hi", "hi")
#    add_doctors()
 #   remove_doctors()
