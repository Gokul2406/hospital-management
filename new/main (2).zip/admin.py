from util import connect, db_name
import random

con = connect()
cur = con.cursor()
cur.execute(f"use {db_name}")

def add_doctors():
    name = input("Enter name: ")
    id = int(input("Enter doctor id: "))
    dept = input("Enter doctor's department: ")
    salary = int(input("Enter salary: "))
    working_hrs = int(input("Enter time of consultancy: "))
    fees = int(input("Enter fees: "))
    doc_insert = f"insert into doctors values({id}, '{name}', '{dept}', {salary}, {working_hrs}, {fees})"
    cur.execute(doc_insert)
    cur.close()
    con.commit()
    con.close()

def update_doctors():
    column = input("Enter column to update: ")
    new_val = input("Enter new value: ")
    old_val = input("Enter old val: ")
    cur.execute(f"update doctors set {column} = {newval} where {column} = {oldval}")

    cur.close()
    con.commit()
    print("success")
    con.close()
    
def remove_doctors():
    id = int(input("Enter doctor's id"))
    remove_doc = f"delete from doctors where doc_id = {id}"
    cur.execute(remove_doc)
    cur.close()
    con.commit()
    print("success")
    con.close()

def add_patients():
    name = input("Enter name: ")
    age = int(input("Enter patients age: "))
    reason= input("Enter reason for consultancy: ")
    doc_id = int(input("Enter doctor id: "))
    id = random.randint(1,1000)
    pat_insert = f"insert into patients values({id}, '{name}', {age}, {doc_id}, '{reason}')"

    cur.execute(pat_insert)
    cur.close()
    con.commit()
    print("success")
    con.close()

def remove_patients():
    id = int(input("Enter patient id: "))
    remove_pat = f"delete from patients where id = {id}"
    cur.execute(remove_pat)
    cur.close()
    con.commit()
    print("success")
    con.close()
